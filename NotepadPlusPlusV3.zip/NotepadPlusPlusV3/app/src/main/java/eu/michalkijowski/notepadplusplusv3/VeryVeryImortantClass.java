package eu.michalkijowski.notepadplusplusv3;

import android.widget.Toast;

import androidx.biometric.BiometricPrompt;

import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.concurrent.Executor;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import static eu.michalkijowski.notepadplusplusv3.MainActivity.preferences;

public class VeryVeryImortantClass {
    private static final String KEY_ALIAS = "passnotepadplusplusv2";

    private static Executor executor;
    private static BiometricPrompt biometricPrompt;
    private static BiometricPrompt.PromptInfo promptInfo;

    public static PublicKey publicKey = null;
    public static PrivateKey privateKey = null;
    public static SecretKey passwordSecret = null;

    public static PublicKey fromPasswordRSAGetPublic()
    {
        try {
            byte[] byteKey = Base64.getDecoder().decode(preferences.getString("biometricPublic", null));
            X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            publicKey = kf.generatePublic(X509publicKey);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            e.printStackTrace();
        }
        return publicKey;
    }
    public static PrivateKey fromPasswordRSAGetPrivate(String password)
    {
        try {
            KeySpec spec = new PBEKeySpec(password.toCharArray(), preferences.getString("saltPrivate", null).getBytes(), 10000, 128);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            passwordSecret = factory.generateSecret(spec);

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            SecretKey secretKey = new SecretKeySpec(passwordSecret.getEncoded(), 0, 32, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);

            String privates = String.valueOf(cipher.doFinal(Base64.getDecoder().decode(preferences.getString("passwordPrivate", null))));

            KeyFactory kf = KeyFactory.getInstance("RSA");
            PKCS8EncodedKeySpec keySpecPKCS8 = new PKCS8EncodedKeySpec(privates.getBytes());
            privateKey = kf.generatePrivate(keySpecPKCS8);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException e) {
            e.printStackTrace();
        }
        return privateKey;
    }
    public static PublicKey fromBiometricRSAGetPublic()
    {
        return null;
    }
    public static PrivateKey fromBiometricRSAGetPrivate()
    {
        return null;
    }
    public static void fromPasswordGenerateRSA(String password)
    {
        try {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            generator.initialize(2048, new SecureRandom());
            KeyPair pair = generator.generateKeyPair();

            SecureRandom srandom = new SecureRandom();
            byte[] salt = new byte[8];
            srandom.nextBytes(salt);
            KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 10000, 128);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            passwordSecret = factory.generateSecret(spec);

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            SecretKey secretKey = new SecretKeySpec(passwordSecret.getEncoded(), 0, 32, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);

            preferences.edit().putString("passwordPublic", Base64.getEncoder().encodeToString(pair.getPublic().getEncoded())).commit();
            preferences.edit().putString("passwordPrivate", Base64.getEncoder().encodeToString(cipher.doFinal(pair.getPrivate().getEncoded()))).commit();
            preferences.edit().putString("ivPrivate", Base64.getEncoder().encodeToString(cipher.getIV())).commit();
            preferences.edit().putString("saltPrivate", Base64.getEncoder().encodeToString(salt)).commit();

            byte[] byteKey = Base64.getDecoder().decode(preferences.getString("biometricPublic", null));
            X509EncodedKeySpec X509publicKey = new X509EncodedKeySpec(byteKey);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            publicKey = kf.generatePublic(X509publicKey);
            privateKey = pair.getPrivate();
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | BadPaddingException | IllegalBlockSizeException | InvalidKeyException | InvalidKeySpecException e) {
            e.printStackTrace();
        }
    }
    public static void fromBiometricGenerateRSA()
    {
        executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt.AuthenticationCallback callback = new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode,
                                              @NonNull CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                Toast.makeText(getApplicationContext(), R.string.autherr, Toast.LENGTH_SHORT).show();
                finishAndRemoveTask();
            }

            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                finishAndRemoveTask();
            }

            @Override
            public void onAuthenticationSucceeded (BiometricPrompt.AuthenticationResult result) {
                if (!flag) update();
                else save(view);
                flag = false;
            }
        };
        biometricPrompt = new BiometricPrompt(this, executor, callback);

        promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Uwierzytelnianie biometryczne")
                .setSubtitle("Pokaż że to Ty jesteś użytkownikiem tego telefonu")
                .setNegativeButtonText(getString(R.string.whiteflag))
                .build();

        biometricPrompt.authenticate(promptInfo);
    }
}
