package eu.michalkijowski.notepadplusplus;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;

public class PasswordSet extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_set);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void checkIdentity(View view)
    {
        String pass1 = ((EditText)findViewById(R.id.setpass1)).getText().toString();
        String pass2 = ((EditText)findViewById(R.id.setpass2)).getText().toString();
        if(pass1.equals(pass2) && !pass1.equals(""))
        {
            try {
                String data = LocalDate.now().toString();
                MainActivity.preferences.edit().putString("date", data).commit();
                String[]dataA = data.split("-");
                pass1 = Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-256").digest((dataA[0]+pass1+dataA[2]).getBytes()));
                MainActivity.preferences.edit().putString("password", pass1).commit();
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(), R.string.identitypassword, Toast.LENGTH_LONG).show();
        }
    }
}